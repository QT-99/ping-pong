#include "raylib.h"
#include <cmath>

// Returns a random song index that is different from the current one
int randomOtherSong(int count, int current)
{
    if (count <= 1)
        return 0;
    int next = current;
    while (next == current)
        next = GetRandomValue(0, count - 1);
    return next;
}

int main()
{
    // Make all file paths relative to where main.exe is, so music/png files are always found
    ChangeDirectory(GetApplicationDirectory());

    const int W = 800;
    const int H = 600;
InitWindow(W, H, "NEON PONG");
Image icon = LoadImage("neon cyberpunk n emblem.png");
SetWindowIcon(icon);
UnloadImage(icon);
InitAudioDevice();
SetTargetFPS(60);
Music homeMusic = LoadMusicStream("grand_project-wonders-of-the-earth-550792.mp3");
SetMusicVolume(homeMusic, 0.25f);
Music* currentMusic = NULL;

// =========================================================
// GAMEPLAY SONGS (the main menu only plays Grand Project)
// To add a song: add its file name to gameMusicFiles, a short name to
// gameMusicNames (same order), and raise SONG_COUNT by 1.
// =========================================================
const int SONG_COUNT = 10;
const char* gameMusicFiles[SONG_COUNT] = {
    "alex-morgan-synthwave-arcade-retro-nights-573647.mp3",
    "arpmedia-retro-arcade-game-music-577821.mp3",
    "mfcc-retro-arcade-game-music-297305.mp3",
    "mickeyscat-moment-of-peace-mickeyscat-554494.mp3",
    "mondamusic-retro-arcade-game-music-512837.mp3",
    "monume-retro-arcade-game-music-498052.mp3",
    "moodmode-retro-game-arcade-236133.mp3",
    "sigmamusicart-no-copyright-music-537751.mp3",
    "slimeyfox-arcade-80s-era-481352.mp3",
    "slimeyfox-haunted-ghost-arcade-80s-541569.mp3"
};
const char* gameMusicNames[SONG_COUNT] = {
    "ALEX MORGAN - SYNTHWAVE NIGHTS",
    "ARPMEDIA - RETRO ARCADE",
    "MFCC - RETRO ARCADE",
    "MICKEYSCAT - MOMENT OF PEACE",
    "MONDAMUSIC - RETRO ARCADE",
    "MONUME - RETRO ARCADE",
    "MOODMODE - RETRO GAME ARCADE",
    "SIGMAMUSICART - NO COPYRIGHT",
    "SLIMEYFOX - ARCADE 80S ERA",
    "SLIMEYFOX - HAUNTED GHOST"
};
Music gameSongs[SONG_COUNT];
int songCount = SONG_COUNT;
for (int i = 0; i < songCount; i++)
{
    gameSongs[i] = LoadMusicStream(gameMusicFiles[i]);
    gameSongs[i].looping = false;
    SetMusicVolume(gameSongs[i], 0.25f);
}
// Song chosen in Settings: -1 = SHUFFLE, 0 and up = that song from the music folder
int musicChoice = -1;
// Which gameplay song is actually playing right now
int gameMusicSelection = (songCount > 0) ? GetRandomValue(0, songCount - 1) : 0;


    // Neon colors
    Color cyan = { 0, 240, 255, 255 };
    Color pink = { 255, 45, 150, 255 };
    Color dark = { 8, 12, 28, 255 };
    Color muted = { 115, 135, 165, 255 };
    // Screens: 0 = menu, 1 = game, 2 = instructions, 3 = settings
    int screen = 0;
    // Difficulty: 0 = Easy, 1 = Medium, 2 = Hard, 3 = Adaptive
    int difficulty = 1;
    int settingsSelection = 0;
    const char* difficultyNames[] = {
        "EASY", "MEDIUM", "HARD", "ADAPTIVE"
    };
    int selected = 0;
    int playerScore = 0;
    int cpuScore = 0;
    // Paddles
    Rectangle player = { 35, 250, 14, 100 };
    Rectangle cpu = { 751, 250, 14, 100 };
    // Ball
    Vector2 ball = { 400, 300 };
    Vector2 ballSpeed = { 360, 190 };
    const float radius = 10;
    bool paused = false;
    while (!WindowShouldClose())
    {
        float dt = GetFrameTime();
        float time = (float)GetTime();
        float pulse = 0.65f + 0.35f * sinf(time * 3);
        // =========================
        // MENU AND SETTINGS CONTROLS
        // =========================
        if (screen == 0)
        {
            if (IsKeyPressed(KEY_DOWN))
                selected = (selected + 1) % 4;
            if (IsKeyPressed(KEY_UP))
                selected = (selected + 3) % 4;
            if (IsKeyPressed(KEY_ENTER))
            {
                if (selected == 0)
                {
                    // Start a new game
                    playerScore = 0;
                    cpuScore = 0;
                    player.y = 250;
                    cpu.y = 250;
                    ball = { 400, 300 };
                    ballSpeed = { 360, 190 };
                    paused = false;
                    // Use the song picked in Settings, or a random one if SHUFFLE
                    if (songCount > 0)
                        gameMusicSelection = (musicChoice >= 0) ? musicChoice : GetRandomValue(0, songCount - 1);
                    screen = 1;
                }
                else if (selected == 1)
                {
                    settingsSelection = difficulty;
                    screen = 3;
                }
                else if (selected == 2)
                {
                    screen = 2;
                }
                else if (selected == 3)
                {
                    break;
                }
            }
        }
        else if (screen == 2)
        {
            // Instructions screen controls
            if (IsKeyPressed(KEY_ENTER) ||
                IsKeyPressed(KEY_ESCAPE))
            {
                screen = 0;
            }
        }
        else if (screen == 3)
        {
            // Settings controls: four difficulty rows plus game music.
            if (IsKeyPressed(KEY_DOWN))
                settingsSelection = (settingsSelection + 1) % 5;
            if (IsKeyPressed(KEY_UP))
                settingsSelection = (settingsSelection + 4) % 5;
            if (IsKeyPressed(KEY_LEFT))
            {
                if (settingsSelection == 4)
                {
                    // Browse songs backwards: SHUFFLE, last song, ..., first song
                    if (songCount > 0)
                    {
                        musicChoice--;
                        if (musicChoice < -1)
                            musicChoice = songCount - 1;
                    }
                }
                else
                    difficulty = settingsSelection;
            }
            if (IsKeyPressed(KEY_RIGHT))
            {
                if (settingsSelection == 4)
                {
                    // Browse songs forwards: SHUFFLE, first song, ..., last song
                    if (songCount > 0)
                    {
                        musicChoice++;
                        if (musicChoice > songCount - 1)
                            musicChoice = -1;
                    }
                }
                else
                    difficulty = settingsSelection;
            }
            if (IsKeyPressed(KEY_ENTER))
            {
                if (settingsSelection == 4)
                {
                    if (songCount > 0)
                    {
                        musicChoice++;
                        if (musicChoice > songCount - 1)
                            musicChoice = -1;
                    }
                }
                else
                {
                    difficulty = settingsSelection;
                    screen = 0;
                }
            }
            if (IsKeyPressed(KEY_ESCAPE))
                screen = 0;
        }
        // =========================
        // GAME CONTROLS AND PHYSICS
        // =========================
        if (screen == 1)
        {
            if (IsKeyPressed(KEY_ESCAPE))
            {
                screen = 0;
                paused = false;
            }
            if (IsKeyPressed(KEY_SPACE))
                paused = !paused;
            if (IsKeyPressed(KEY_M))
                gameMusicSelection = randomOtherSong(songCount, gameMusicSelection);
            if (!paused)
            {
                // Move player paddle
                if (IsKeyDown(KEY_W) || IsKeyDown(KEY_UP))
                    player.y -= 420 * dt;
                if (IsKeyDown(KEY_S) || IsKeyDown(KEY_DOWN))
                    player.y += 420 * dt;
                // Keep player paddle inside the window
                if (player.y < 0)
                    player.y = 0;
                if (player.y + player.height > H)
                    player.y = H - player.height;
                // CPU speed depends on difficulty
                float cpuSpeed = 320.0f;
                if (difficulty == 0)
                    cpuSpeed = 180.0f;
                else if (difficulty == 1)
                    cpuSpeed = 320.0f;
                else if (difficulty == 2)
                    cpuSpeed = 500.0f;
                else
                    cpuSpeed = 320.0f; // Adaptive placeholder
                // Move CPU toward the ball
                float cpuCenter = cpu.y + cpu.height / 2;
                if (cpuCenter < ball.y - 10)
                    cpu.y += cpuSpeed * dt;
                else if (cpuCenter > ball.y + 10)
                    cpu.y -= cpuSpeed * dt;
                // Keep CPU paddle inside the window
                if (cpu.y < 0)
                    cpu.y = 0;
                if (cpu.y + cpu.height > H)
                    cpu.y = H - cpu.height;
                // Move ball
                ball.x += ballSpeed.x * dt;
                ball.y += ballSpeed.y * dt;
                // Bounce off top and bottom
                if (ball.y - radius <= 0)
                {
                    ball.y = radius;
                    ballSpeed.y = fabsf(ballSpeed.y);
                }
                if (ball.y + radius >= H)
                {
                    ball.y = H - radius;
                    ballSpeed.y = -fabsf(ballSpeed.y);
                }
                // Ball hits player paddle
                if (ballSpeed.x < 0 &&
                    CheckCollisionCircleRec(ball, radius, player))
                {
                    ball.x = player.x + player.width + radius;
                    ballSpeed.x = fabsf(ballSpeed.x) * 1.04f;
                    float offset =
                        (ball.y - (player.y + player.height / 2)) /
                        (player.height / 2);
                    ballSpeed.y = offset * 330;
                }
                // Ball hits CPU paddle
                if (ballSpeed.x > 0 &&
                    CheckCollisionCircleRec(ball, radius, cpu))
                {
                    ball.x = cpu.x - radius;
                    ballSpeed.x = -fabsf(ballSpeed.x) * 1.04f;
                    float offset =
                        (ball.y - (cpu.y + cpu.height / 2)) /
                        (cpu.height / 2);
                    ballSpeed.y = offset * 330;
                }
                // Player misses the ball
                if (ball.x < -radius)
                {
                    cpuScore++;
                    ball = { 400, 300 };
                    ballSpeed = { 360, 190 };
                }
                // CPU misses the ball
                if (ball.x > W + radius)
                {
                    playerScore++;
                    ball = { 400, 300 };
                    ballSpeed = { -360, -190 };
                }
            }
        }
        // =========================
        // Grand Project plays on the menu.
        // In Settings, the highlighted song plays as a preview while you browse.
        // During a match, the chosen song plays (or random songs if SHUFFLE).
        // When a song ends: SHUFFLE picks a new random song, a chosen song repeats.
        bool playingGameSong = (songCount > 0 && currentMusic != NULL &&
            currentMusic >= &gameSongs[0] && currentMusic < &gameSongs[0] + songCount);
        if (playingGameSong && !IsMusicStreamPlaying(*currentMusic))
        {
            if (screen == 1 && musicChoice < 0 && songCount > 1)
                gameMusicSelection = randomOtherSong(songCount, gameMusicSelection);
            else
                PlayMusicStream(*currentMusic);
        }
        Music* desiredMusic = &homeMusic;
        if (screen == 1)
            desiredMusic = (songCount > 0) ? &gameSongs[gameMusicSelection] : NULL;
        else if (screen == 3 && settingsSelection == 4 && musicChoice >= 0)
            desiredMusic = &gameSongs[musicChoice];
        if (desiredMusic != currentMusic)
        {
            if (currentMusic != NULL)
                StopMusicStream(*currentMusic);
            currentMusic = desiredMusic;
            if (currentMusic != NULL)
                PlayMusicStream(*currentMusic);
        }
        if (currentMusic != NULL)
            UpdateMusicStream(*currentMusic);
        // DRAW
        // =========================
        BeginDrawing();
        // Background gradient
        DrawRectangleGradientV(
            0, 0, W, H, dark,
            Color{ 15, 10, 35, 255 }
        );
        // Court border
        DrawRectangleLinesEx(
            Rectangle{ 15, 15, 770, 570 },
            1, Fade(cyan, 0.22f)
        );
        // Decorative neon glow
        DrawCircleGradient(
            Vector2{ 0, 300 }, 260,
            Fade(cyan, 0.09f),
            Fade(dark, 0.0f)
        );
        DrawCircleGradient(
            Vector2{ 800, 300 }, 260,
            Fade(pink, 0.09f),
            Fade(dark, 0.0f)
        );
        // =========================
        // MAIN MENU
        // =========================
        if (screen == 0)
        {
            const char* title = "NEON PONG";
            int titleWidth = MeasureText(title, 58);
            DrawText(
                title, (W - titleWidth) / 2,
                100, 58, WHITE
            );
            DrawText(
                "THE CLASSIC ARCADE CHALLENGE",
                190, 170, 19, muted
            );
            const char* options[] = {
                "PLAY GAME",
                "SETTINGS",
                "HOW TO PLAY",
                "EXIT"
            };
            for (int i = 0; i < 4; i++)
            {
                int y = 270 + i * 65;
                Color optionColor =
                    (i == selected) ? cyan : LIGHTGRAY;
                if (i == selected)
                {
                    DrawRectangleRounded(
                        Rectangle{
                            225, (float)y - 8, 350, 48
                        },
                        0.3f, 8,
                        Fade(cyan, 0.10f * pulse)
                    );
                    DrawText(">", 250, y, 28, cyan);
                }
                int textWidth = MeasureText(options[i], 24);
                DrawText(
                    options[i],
                    400 - textWidth / 2,
                    y, 24, optionColor
                );
            }
            DrawText(
                "UP / DOWN TO SELECT  -  ENTER TO CONFIRM",
                165, 520, 16, muted
            );
        }
        // =========================
        // SETTINGS SCREEN
        // =========================
        // SETTINGS SCREEN
        // =========================
        else if (screen == 3)
        {
            DrawText("SETTINGS", 300, 75, 38, cyan);
            DrawText("CHOOSE CPU DIFFICULTY OR GAME MUSIC", 170, 125, 17, muted);
            for (int i = 0; i < 4; i++)
            {
                int y = 175 + i * 45;
                Color optionColor = (i == settingsSelection) ? WHITE : muted;
                if (i == settingsSelection)
                {
                    DrawRectangleRounded(Rectangle{ 220, (float)y - 5, 360, 38 },
                        0.3f, 8, Fade(cyan, 0.15f));
                    DrawText(">", 238, y, 23, cyan);
                }
                DrawText(difficultyNames[i], 275, y, 21, optionColor);
                if (difficulty == i)
                    DrawText("CURRENT", 455, y + 3, 14, pink);
            }
            int musicY = 370;
            if (settingsSelection == 4)
            {
                DrawRectangleRounded(Rectangle{ 220, (float)musicY - 5, 360, 38 },
                    0.3f, 8, Fade(cyan, 0.15f));
                DrawText(">", 238, musicY, 23, cyan);
            }
            DrawText("GAME MUSIC",
                275, musicY, 20, settingsSelection == 4 ? WHITE : muted);
            // Currently chosen song (or SHUFFLE) with its position in the list
            const char* musicName = "< SHUFFLE >";
            if (songCount == 0)
                musicName = "NO SONGS FOUND";
            else if (musicChoice >= 0)
                musicName = TextFormat("< %s  (%i/%i) >",
                    gameMusicNames[musicChoice],
                    musicChoice + 1, songCount);
            DrawText(musicName, 275, musicY + 30, 12, cyan);
            DrawText(TextFormat("%i SONGS - LEFT / RIGHT TO BROWSE, SONG PREVIEWS", songCount),
                275, musicY + 50, 10, muted);
            DrawText("UP / DOWN: SELECT   LEFT / RIGHT OR ENTER: CHANGE", 80, 465, 14, muted);
            DrawText("ENTER ON A DIFFICULTY: APPLY   ESC: BACK", 115, 490, 14, muted);
        }

        // HOW TO PLAY SCREEN
        // =========================
        else if (screen == 2)
        {
            DrawText("HOW TO PLAY", 270, 100, 38, cyan);
            DrawText(
                "W / S or UP / DOWN  -  Move your paddle",
                145, 230, 20, WHITE
            );
            DrawText(
                "SPACE  -  Pause or resume",
                200, 285, 20, WHITE
            );
            DrawText(
                "ESC  -  Return to menu",
                205, 340, 20, WHITE
            );
            DrawText(
                "ENTER  -  Return to menu",
                205, 395, 20, WHITE
            );
            DrawText(
                "Press ENTER to return",
                270, 510, 18, muted
            );
        }
        // =========================
        // GAME SCREEN
        // =========================
        else if (screen == 1)
        {
            // Center dashed line
            for (int y = 35; y < H; y += 30)
            {
                DrawRectangle(
                    397, y, 6, 16,
                    Fade(WHITE, 0.30f)
                );
            }
            // Scoreboard
            DrawText(
                TextFormat("%02i", playerScore),
                300, 48, 50, cyan
            );
            DrawText(
                TextFormat("%02i", cpuScore),
                455, 48, 50, pink
            );
            DrawText("YOU", 302, 105, 14, muted);
            DrawText("CPU", 460, 105, 14, muted);
            // Small song label (name cut to 26 characters so it never gets too wide)
            const char* songLabel = (songCount > 0)
                ? TextFormat("%s  (M: SHUFFLE)",
                    gameMusicNames[gameMusicSelection])
                : "NO SONGS FOUND";
            int labelWidth = MeasureText(songLabel, 10);
            DrawText(songLabel, (W - labelWidth) / 2, 135, 10, muted);
            // Paddle glow
            DrawRectangleRounded(
                Rectangle{
                    player.x - 5, player.y - 5,
                    player.width + 10,
                    player.height + 10
                },
                0.5f, 8, Fade(cyan, 0.12f * pulse)
            );
            DrawRectangleRounded(
                Rectangle{
                    cpu.x - 5, cpu.y - 5,
                    cpu.width + 10,
                    cpu.height + 10
                },
                0.5f, 8, Fade(pink, 0.12f * pulse)
            );
            // Paddles
            DrawRectangleRounded(player, 0.5f, 8, cyan);
            DrawRectangleRounded(cpu, 0.5f, 8, pink);
            // Ball glow
            DrawCircleGradient(
                ball, 27,
                Fade(WHITE, 0.22f * pulse),
                Fade(WHITE, 0.0f)
            );
            DrawCircleV(ball, radius, WHITE);
            DrawCircleLines(
                (int)ball.x, (int)ball.y,
                radius + 2, Fade(cyan, pulse)
            );
            // Pause overlay
            if (paused)
            {
                DrawRectangle(
                    0, 0, W, H, Fade(BLACK, 0.65f)
                );
                DrawText("PAUSED", 315, 255, 42, WHITE);
                DrawText(
                    "PRESS SPACE TO RESUME",
                    255, 320, 18, cyan
                );
            }
            else
            {
                DrawText(
                    "SPACE: PAUSE",
                    25, 555, 14, muted
                );
                DrawText(
                    "ESC: MENU",
                    665, 555, 14, muted
                );
            }
        }
        EndDrawing();
    }
if (currentMusic != NULL)
    StopMusicStream(*currentMusic);
UnloadMusicStream(homeMusic);
for (int i = 0; i < songCount; i++)
    UnloadMusicStream(gameSongs[i]);
CloseAudioDevice();
CloseWindow();
return 0;
}
//to anybody who is checking out the source code nehmia girma made it take this code dont cange anything else besides the music dont try to make it neater or something like that
